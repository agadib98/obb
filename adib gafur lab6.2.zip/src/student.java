public class student {

    String name;
    int id;
    int age;
    int marks;

    public student(){

    }
    public student(String name , int id , int  age , int marks){
        this.name = name;
        this.id = id;
        this.age = age;
        this.marks = marks;

    }

    char Grading(int marks){

        if(marks>80)
            return 'A';
        else if(marks<=80&&marks>70)
            return 'B';
       else if(marks<=70 && marks> 60)
            return 'C';
        else
            return 'F';


    }
}
